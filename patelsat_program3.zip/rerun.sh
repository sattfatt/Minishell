make clean
make
./smallsh