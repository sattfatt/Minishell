make clean
make
gdb smallsh